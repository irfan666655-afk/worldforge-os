# Promotion-Rule Red-Team — Candidate Rules for lint_worldforge.py

**Date:** 2026-07-12 · Fable 5 architecture session
**Threat model:** a lazy or hurried future operator (human or agent) who wants an asset in locked state with minimum ceremony — not a sophisticated attacker. Attacks exploit gaps between what current rules *check* and what doctrine *means*.
**Current coverage (from rules.v1.json bootstrap / doctrine):** GOV-1 reason required · GOV-1b actor required · GOV-2 high-impact approver gate · GOV-3 fingerprint-missing warn · SCHEMA-1/2 type+name required.
**Format:** rows ready for the linter rule table; predicates marked NEW must be added to both the Python linter and the JS `PREDICATES` map in the ext (DSL lockstep requirement, per gen_rules.py docstring).

---

## GOV-4 — Self-approval on gated promotions

**Threat closed:** GOV-2 demands "a second approver" but nothing stops the operator from typing their own name in the approver field. The gate becomes a second text box, not a second person.
**Detection:** on promotion context where `impact >= high`: fire if `promotion.approver == promotion.actor` (normalized: trim, case-fold; also fire if approver id not present in `agent-roster.v5.2.json` — an invented approver is the same attack).
**Predicate:** `self_or_unknown_approver` (NEW) — params `{roster_path}`.
**Severity:** `error` (hard-fail; a self-approved GOV-2 act is doctrinally void, not merely suspicious).

```json
{
  "id": "GOV-4",
  "doctrine": "Rule 7 (impact escalation, approver independence)",
  "predicate": "self_or_unknown_approver",
  "params": {},
  "severity": "error",
  "message": "GOV-2 approver must be a roster agent distinct from the actor: self-approval or unknown approver detected.",
  "tags": ["promotion"]
}
```

## GOV-5 — Stale fingerprint at promotion (bytes swapped after registration)

**Threat closed:** GOV-3 only checks the fingerprint field *exists*. Operator registers innocuous bytes (fingerprint recorded), swaps the stored bytes, then promotes — record looks clean, canon is poisoned. Rule 4's diff-against-canon guarantee is defeated.
**Detection:** at promotion time, recompute digest from the storage adapter (P2-D-bytes: IndexedDB under `wfproj:`) and compare to `asset.fingerprint`. Tri-state semantics preserved: `mismatch` → fire error; `unverifiable` (no bytes readable) → fire warn — never silently pass, never false-fail (Rule 4 tri-state discipline from v1.1 ext).
**Predicate:** `fingerprint_stale` (NEW, async-capable in JS evaluator) — params `{on_unverifiable: "warn"}`.
**Severity:** `error` on mismatch / `warn` on unverifiable (two table rows or a severity-by-outcome predicate — recommend two rows, GOV-5 and GOV-5b, to keep predicates pure).

## GOV-6 — Locked-asset mutation without a decision record

**Threat closed:** promotion locks the asset, but nothing today prevents editing the locked record in place afterward (name, bytes reference, fingerprint field itself). The lazy operator's cheapest bypass isn't a dirty promotion — it's a clean promotion followed by quiet edits. This also closes the GOV-5 laundering route (edit fingerprint field to match swapped bytes).
**Detection:** linter pass over project state: for each asset with `locked: true`, compute digest of the locked record's governed fields (id, type, name, fingerprint, bytes-ref) and compare to the digest stored **inside its promoting decision record** at promote time. Mismatch with no subsequent decision record referencing `asset_id` ⇒ fire. Requires one additive field on the decision record: `asset_digest` (additive = frozen-schema-compatible; see UFDM v2 notes §3). In-browser ext enforces the write-path version: reject any `updateAsset` on `locked:true` unless accompanied by a decision context.
**Predicate:** `locked_mutation_without_decision` (NEW) — params `{}`.
**Severity:** `error`.

## GOV-7 — Reason-quality floor (rubber-stamp detection)

**Threat closed:** GOV-1 is satisfied by `reason: "."`. Rule 12's intent is a *reviewable* reason; the literal check invites keystroke-minimum compliance.
**Detection:** fire if `promotion.reason` trimmed length < 10 chars, OR matches a boilerplate denylist (`ok`, `asap`, `done`, `n/a`, `.`, `-`, `test`), OR is byte-identical to the reason on any of the actor's previous 3 decision records in this project (copy-paste ritual).
**Predicate:** `reason_below_floor` (NEW) — params `{min_len: 10, denylist: […], repeat_window: 3}`.
**Severity:** `warn` (advisory friction, not a hard gate — a hard gate here just trains operators to write 10-char garbage; the warn lands in the promotion UI pre-submit and in CI reports where the pattern becomes visible across a project).

## GOV-8 — Orphan lock / dangling decision (ledger referential integrity)

**Threat closed:** two inverse corruptions the current rules never look at because they only inspect the promotion *event*, not the resulting *state*: (a) an asset arrives in `locked:true` with no decision record naming it — e.g. hand-edited storage, or a UFDM import of a doctored document; (b) a decision record references an `asset_id` that doesn't exist (deleted after promotion, or fabricated ledger padding). Either breaks the "every locked state is testified" invariant, and P3's V3 view (orphan-lock red rendering) needs this rule as its data source.
**Detection:** set difference in both directions: `{locked assets} \ {assets named by promote-kind decisions}` and `{asset_ids in decisions} \ {existing assets}`. Runs as a linter state pass and as a UFDM-import validation step (imports are the cheapest injection point for pre-locked assets — this is the direct machine check for Rule 12 on the import path).
**Predicate:** `ledger_referential_integrity` (NEW) — params `{}`.
**Severity:** `error`.

---

## Integration notes

1. All five are `tags: ["promotion"]` (GOV-8 additionally `["import","state"]`) so `gen_rules.py` source-resolution picks them up unchanged via `PROMOTION_RULES` / tag filter.
2. Four NEW predicates extend the DSL: `self_or_unknown_approver`, `fingerprint_stale`, `locked_mutation_without_decision`, `reason_below_floor`, `ledger_referential_integrity`. Each must land in the Python linter and the JS `PREDICATES` map **in the same change**, with a smoke test per predicate (mock-kernel pattern from the v1.1 session).
3. GOV-5 and GOV-6 depend on the storage adapter read path and the `asset_digest` additive field — sequence them after P2 integration; GOV-4, GOV-7, GOV-8 are implementable now against the bootstrap evaluator.
4. `RECONCILE(lint-src)` still applies: rule IDs GOV-4..8 assume the real linter hasn't already claimed those IDs. Renumber on collision; threat mapping is the stable identity, not the ID.
