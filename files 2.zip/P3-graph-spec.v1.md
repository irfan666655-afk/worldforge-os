# P3-graph-spec.v1 — Canonical Graph Visualization Contract

**Status:** FROZEN (design decisions closed; P3 is execution, not design)
**Date:** 2026-07-12 · Fable 5 architecture session
**Supersedes:** decorative escalation spokes in `worldforge-os_3.html` / `foundry-visualizer.js` ("visual only" per code comment). foundry-visualizer retires when this ships.
**Depends on:** P2 kernel ext (`wfkernel-p2-ext.v1.1.js`+), canonical `agent-roster.v5.2.json`, `pipeline.v1.json`, decision ledger records (Rule 7 frozen shape).

---

## 1. First-class canonical edges (FROZEN)

Exactly three edge families are first-class. Anything else is derived styling, not graph data.

| Edge family | Source of truth | Direction | Node types | Doctrine hook |
|---|---|---|---|---|
| **E1 Escalation** | `agent-roster.v5.2.json` per-agent escalation paths | agent → agent (or agent → guild-lead) | agent, guild-lead | Rule 13: depth > 3 or undefined-target renders **red**; linter findings render in-scene |
| **E2 Pipeline sequence** | `pipeline.v1.json` `stages[]` order + gate annotations | stage → next stage | stage; gate badge on edge where Rules 3/4/11 gate | Gate hard/soft semantics color the badge |
| **E3 Promotion chain** | project decision ledger (`decisions[]`) | decision → asset (promoted); decision → approver (GOV-2 acts) | decision, asset, agent | Rule 12 / Rule 7: every locked asset must have an inbound E3 edge — a locked asset with no E3 edge renders **red** (orphan lock) |

Edge IDs are deterministic: `E1:<from_agent>:<to_agent>`, `E2:<stage>:<stage>`, `E3:<decision_id>:<target_id>`. Deterministic IDs make diff-patching and test assertions possible.

## 2. Read API (kernel side — the only data path)

The graph module consumes the P2 ext surface **only**. It never reads storage, never parses canonical JSON itself, never probes capabilities (P4-D pattern: boot decides, components consume).

```
kernel.getRoster()      → {agents:[…]}          // canonical injected at install()
kernel.getPipeline()    → {stages:[…]}
kernel.getAssets()      → asset records incl. locked, fingerprint
kernel.getDecisions()   → decision ledger (frozen Rule 7 shape)   // MARKER: VERIFY(kernel-src) — confirm getter name vs direct state.decisions; ext export path handles both `decisions`/`decision_log`
kernel.subscribe(fn)    → unsubscribe            // same subscription driving P2 component re-renders
```

Graph module contract mirrors P2 components exactly: `mount(el, kernel, opts) / update(snapshot) / destroy()`, UMD-wrapped, no globals beyond the UMD export `WFGraph`.

## 3. Reactivity model: **snapshot-on-event** (DECIDED)

On every kernel event, take one atomic snapshot via the getters, recompute the full graph model, diff against previous edge/node ID sets, patch the DOM. Justification (3 lines):

1. Governance state mutates at human cadence (a promotion, a decision) — there is no streaming data to justify fine-grained reactivity, and a full recompute over ~40 agents + ~10 stages + decisions is sub-millisecond.
2. A snapshot guarantees the rendered graph corresponds to exactly one consistent state version — no torn view where an asset shows locked but its decision edge hasn't arrived (governance UI must never display a state the ledger can't testify to).
3. It is the same subscription mechanism P2 components already use — one reactivity model across the surface, zero new machinery under the no-build-chain constraint.

## 4. Render technology: **layered SVG** (DECIDED)

SVG, not Three.js, for all three P3 views. Rationale: node count is small (≤ ~60 nodes/view); SVG is real DOM — every node/edge is focusable, labelable (`role="img"` + `aria-label`, title elements), satisfying the P2-folded WCAG 2.1 AA criteria natively where WebGL requires a parallel text tree; zero CDN dependency and zero WebGL requirement collapses the failure surface; works `file://` with plain `<script>` tags. Three.js remains only in the legacy explore mode until foundry retirement completes — **no new Three.js code in P3**.

Layout: static computed layouts, no physics engine — E1 uses guild-clustered radial columns (guild lanes, escalation arrows upward toward leads/authority roles, depth visible as column distance); E2 is a fixed vertical stage rail (9:16-friendly); E3 renders as an asset-centric timeline (decisions ordered by `ts`, edges to asset + approver). Deterministic layout = screenshot-diffable QA.

## 5. Degradation path (consistent with text-roster.js)

Single shared path, same as P4-D: any failure to mount the graph module (script error, missing canonical data) fires the existing `wf:vendor-fallback` event with `{reason}` and mounts `components/text-roster.js` in the same container. No second fallback branch. Because SVG needs no WebGL and no CDN, the realistic trigger is data-shape failure only — which is exactly what the text roster (canonical-JSON-driven) survives. Boot performs the probe/decision; the graph module itself never capability-sniffs.

## 6. Views and acceptance criteria

### V1 — Escalation graph (retires foundry explore mode)
- [ ] Every agent in `agent-roster.v5.2.json` appears exactly once; every declared escalation path appears as exactly one E1 edge — count asserted in a smoke test against canonical JSON
- [ ] Rule 13 violations (depth > 3, undefined target) render red with a findings tooltip; zero violations in v5.2 canon ⇒ zero red edges (regression tripwire)
- [ ] Guild clustering visible; authority roles (guild leads) visually distinct
- [ ] Keyboard: Tab into graph, arrows traverse nodes, Enter expands an agent's full escalation chain, Escape collapses — identical key map to text-roster.js
- [ ] Snapshot-on-event: editing roster data in a test harness and firing a kernel event re-renders within one frame, no reload

### V2 — Pipeline stage rail
- [ ] All stages from `pipeline.v1.json` in canonical order; gate badges on gated edges with hard/soft styling
- [ ] Current project stage highlighted from kernel state; advancing the stage via kernel updates the highlight without reload
- [ ] Gate badge activates the same gate modal used by the v3 build (no duplicate gate UI)

### V3 — Promotion chain view
- [ ] Selecting a locked asset shows its full E3 chain: decision record(s) → approver(s), fields from the frozen Rule 7 shape
- [ ] A locked asset with no decision record renders red "orphan lock" (this is a display of linter rule GOV-P3 territory — see red-team candidates)
- [ ] Tri-state fingerprint status (verified / mismatch / unverifiable) shown per asset with distinct non-color-only indicators (AA)
- [ ] Chain renders identically from a UFDM import roundtrip (export → import → same E3 edges)

### Cross-cutting
- [ ] Single file build: module concatenates via `build.mjs` manifest, UMD-wrapped, hash-stamped
- [ ] `file://` in Chrome/Firefox/Safari, zero console errors
- [ ] axe scan clean on all three views; contrast ≥ 3:1 on non-text graph indicators

## 7. Out of scope (named, so no scope creep)

Force-directed layout, pan/zoom beyond CSS overflow, editing via the graph (graph is read-only inspection; mutations go through P2 workflows), rendering Jaidi/creative-asset thumbnails in-graph (UFDM v2 byte territory).

## 8. Open markers

- `VERIFY(kernel-src)` — decisions getter name (§2)
- `P3-M1` — whether foundry retirement is a delete or a redirect stub (Irfan's call; recommend delete + decision record, foundry is a strict subset per the audit)
