# Handoff Addendum — 2026-07-12 session (append to P2-P4-execution-handoff.md)

**Prepared by:** Fable 5 architecture session · **Audience:** Sonnet/Opus executing in Claude Code. Execute; do not re-derive decisions.

---

## 0. Source gate result — Track A NOT run

`worldforge-kernel.v1.js`, `worldforge-os_3.html`, `foundry-visualizer.js`, `lint_worldforge.py` were **absent again** this session. Per the gate, all source-bound work was skipped — **no partial source work was attempted from fragments** (known-bad approach). Consequences you inherit:

- `wfkernel-p2-ext` remains at **v1.1** — all `VERIFY(kernel-src)` markers still open. No v1.2 exists. The seam-replacement architecture means the ext is correct regardless; the markers are confirmations, not blockers to reading the code.
- `gen_rules.py` still runs on the **BOOTSTRAP_TABLE** (`source: "bootstrap"`, RULES-PROVENANCE warning active). `RECONCILE(lint-src)` markers open.
- **The P4 inventory categorization map (kernel/component/vendor/dead per code block) does NOT exist.** P4 extraction execution remains hard-blocked — do not attempt extraction without that map; miscategorization is the known failure mode. Building the map is a ~1h task once `worldforge-os_3.html` is attached: one artifact, per-block ID / category / destination module / confidence / MUST-VERIFY flag on anything ambiguous.

**Your first action is unchanged from the prior handoff: get the four files attached, burn down the markers, then build the categorization map.**

## 1. What is now BOUND (decided, frozen — do not reopen)

| Decision | Where |
|---|---|
| P2-D-bytes: asset bytes in IndexedDB via injected storage adapter under `wfproj:`; UFDM embeds bytes on explicit toggle only | Ratified by Irfan; encoded in UFDM-v2-notes §2 and GOV-5 detection path |
| P4-D1–D4 | Ratified as drafted (prior session) |
| P3 graph: three first-class edge families (escalation / pipeline / promotion-chain), snapshot-on-event reactivity, **SVG render (no new Three.js)**, single degradation path into text-roster.js via `wf:vendor-fallback`, mount/update/destroy + UMD contract | `P3-graph-spec.v1.md` — FROZEN. **P3 is now execution, not design.** |

## 2. What is SEAM-LEVEL / provisional (verify before relying on)

- Ext ↔ kernel binding: capability chains + injected seams (v1.1 posture). Markers: persist method name & key scheme, decisions getter/field name, `updateBudget` entry shape, decision-record field names vs frozen schema, asset-schema minimums vs v3.1.
- `rules.v1.json`: bootstrap provenance until the real linter table imports.
- UFDM v2: **notes tier only** (`UFDM-v2-notes.v1.md`). v1 stays authoritative until a GOV-2 act. Do not implement v2 unprompted; the migration function and coexistence policy are pre-designed there when the act lands.

## 3. New rule candidates pending linter integration

`promotion-rule-redteam.v1.md` — five candidates: **GOV-4** self/unknown-approver (error) · **GOV-5/5b** stale fingerprint at promotion, tri-state (error/warn) · **GOV-6** locked-mutation-without-decision, needs additive `asset_digest` on decision records (error) · **GOV-7** reason-quality floor (warn) · **GOV-8** ledger referential integrity, also the import-path validator and the data source for P3 V3 orphan-lock rendering (error).

Sequencing: GOV-4/7/8 implementable now against the bootstrap evaluator; GOV-5/6 after P2 storage-adapter integration. Every new predicate lands in the Python linter **and** the JS `PREDICATES` map in the same change, each with a mock-kernel smoke test. Renumber IDs if the real linter has claimed GOV-4+.

## 4. Updated execution order

1. Attach four source files → burn `VERIFY(kernel-src)` / `RECONCILE(lint-src)` (~30 min) → ext v1.2, linter-derived `rules.v1.json`, `--check` exit 0
2. Build P4 categorization map from real `worldforge-os_3.html` (~1 h) → then P4 extraction per prior handoff (P4 modularization stays gated on P2 completion — no competing refactors on the same HTML surface)
3. P2 integration per prior handoff §2 (MockKernel swap, load order: kernel → ext → components → boot; plain `<script>`, no modules)
4. GOV-4/7/8 into linter + JS evaluator; GOV-5/6 after step 3
5. P3 execution against `P3-graph-spec.v1.md` acceptance criteria (V1 retires foundry explore; resolve marker `P3-M1` — delete vs stub — with Irfan, recommendation on record: delete + decision record)

## 5. Session artifact inventory

| File | Tier |
|---|---|
| `P3-graph-spec.v1.md` | FROZEN spec |
| `promotion-rule-redteam.v1.md` | Candidates for linter inclusion |
| `UFDM-v2-notes.v1.md` | Notes (v1 authoritative) |
| `P2-P4-handoff-addendum.2026-07-12.md` | This document — append to the existing handoff |
