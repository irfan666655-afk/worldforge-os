# UFDM-v2-notes.v1 — Format Hardening (NOTES TIER)

**Status:** NOTES — not a frozen spec. **UFDM v1 remains authoritative** until a GOV-2 act promotes v2. Nothing here changes shipped behavior.
**Date:** 2026-07-12 · Fable 5 architecture session
**Ratified inputs honored:** P2-D-bytes = asset bytes live in IndexedDB via the injected storage adapter under the `wfproj:` prefix; UFDM export embeds bytes on **explicit toggle only**.

---

## 1. Fingerprint semantics (tightened, v1-compatible)

- **Format:** `sha256:<lowercase hex>` — algorithm prefix mandatory in v2 so the field is self-describing and a future algorithm migration is a value change, not a schema change. v1 documents with bare hex are migrated by prefixing (see §4).
- **Byte source of truth:** the storage-adapter blob at the asset's `wfproj:`-prefixed key. The fingerprint always describes those bytes, never an external URL's current content.
- **Lifecycle:** computed at `registerAsset` (when bytes present), re-verified at promotion (red-team GOV-5) and on demand (`verifyAssetFingerprint`). Tri-state result is doctrine: `verified | mismatch | unverifiable` — `unverifiable` is a first-class state, never coerced to pass or fail.
- **v2 additive field:** decision records gain optional `asset_digest` (digest of the asset's governed fields at promote time) — the anchor for GOV-6 locked-mutation detection. Additive-optional keeps the Rule 7 frozen shape intact: old records simply lack it and GOV-6 skips them.

## 2. Byte-embedding rules (under P2-D-bytes, ratified)

- **Default export:** metadata-only. Asset carries `fingerprint`, `bytes_ref` (the storage key), `bytes_size`, `mime`. Documents stay small, diffable, versionable.
- **Explicit toggle (`embed_bytes: true` at export):** adds per-asset `bytes: {encoding:"base64", data:…}`. Guards: per-asset size ceiling (default 8 MB, configurable in export opts) and a document total ceiling (default 64 MB) — exceeding either downgrades that asset to metadata-only and records it in the export manifest (`embedded: false, reason: "size"`), never fails the whole export silently or noisily.
- **Import side (the trust boundary):** embedded bytes are **digest-verified against the asset's fingerprint before being written** to IndexedDB. Mismatch ⇒ asset imported metadata-only with a `mismatch` verification state and a linter finding (GOV-5 semantics); bytes are discarded. An import can add bytes; it can never overwrite existing verified bytes with mismatching ones.
- **Locked-asset imports** additionally pass GOV-8 referential integrity (a locked asset must arrive with its testifying decision record or it imports as red/orphaned, not silently trusted).

## 3. Schema evolution / forward-compat policy

- `ufdm_version: "2.0.0"` (semver, top-level, required). v1 documents (missing the field or `1.x`) are detected and routed to migration.
- **Within a major:** additive-optional only. Removing or re-typing a field is a major bump. This is the same discipline as the Rule 7 frozen decision shape, applied document-wide.
- **Unknown-field preservation:** importers MUST round-trip unknown fields untouched (parse → hold → re-emit). A v2.3 document surviving a v2.1 tool unmutilated is the forward-compat guarantee.
- **Experiment namespace:** keys under `x_*` (top-level and per-asset) are reserved for unstable experiments; validators ignore them, exporters preserve them, and nothing in `x_*` may ever be load-bearing for governance.
- **Validator posture:** `validateUFDM` rejects on missing required fields and wrong types, warns on unknown *versions*, and stays silent on unknown *fields* — strict on what it knows, tolerant of what it doesn't.

## 4. Migration path v1 → v2

- `migrateUFDM(docV1) → docV2`: a pure function, no I/O. Steps: stamp `ufdm_version:"2.0.0"`; prefix bare-hex fingerprints with `sha256:`; synthesize `bytes_ref` from the known `wfproj:` key scheme where absent (`VERIFY(kernel-src)`: key scheme `prefix + id` verbatim — same open marker as the ext); leave decision records byte-identical (`asset_digest` stays absent on historic records by design).
- Migration is **explicit and recorded**: performing it emits a decision record (`kind: "migration"`, impact `low`) — format changes are governance events like everything else.
- **Rollback:** v2→v1 down-migration is lossy only in additive fields; the migrator refuses to down-migrate if any asset has embedded bytes or `asset_digest`-bearing decisions unless `--force`, which itself records a decision.
- **Coexistence window:** exporters emit v1 by default until the GOV-2 promotion act; `--v2` flag opts in. Importers accept both from day one. The flip is a one-line default change plus a ledger entry.

## 5. Open questions (deliberately not decided at notes tier)

- `UFDM2-Q1` — compression for embedded bytes (base64 inflates ~33%; gzip-in-base64 vs plain): defer until a real export exceeds the ceiling in practice.
- `UFDM2-Q2` — whether the export manifest itself gets fingerprinted (document-level integrity seal): attractive for the Instagram-distribution provenance story, but wait for a consumer.
- `UFDM2-Q3` — multi-project bundle format (Data Darbar + Jaidi in one archive): out of scope until a cross-project workflow exists.
